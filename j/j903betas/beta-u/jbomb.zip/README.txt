README.txt

Reproduce J beta-u "vanishing" act.

The files in this zip should be run on Windows 10 system.

1) Unzip the contents of jbomb.zip to this directory layout.

c:\jbomb\

with subdirectories 

c:\jbomb\jod
c:\jbomb\utils

Note: That path to the JOD system root is set in 
the first few lines of jod.ijs in verb (jodsystempath_z_)

2) Start j903 (I use JQT)

3) Load the required JOD script with:

0!:0<'c:/jbomb/jod/jod.ijs'

4) register the test dictionary with:

regd 'utils';'c:/jbomb/utils'

5) after step 4 the following should show (utils)

od ''

6) open (utils)

od 'utils'

7) The next expression "vanishes" the JQT window

'boo' rxs }. dnl ''

